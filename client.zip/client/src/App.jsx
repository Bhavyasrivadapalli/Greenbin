import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';

import AddBinForm from './components/AddBinForm';
import BinMap from './components/BinMap';
import BinTable from './components/BinTable';
import BinAnalytics from './components/BinAnalytics';
import BinDashboard from './components/BinDashboard';
import Navbar from './components/Navbar';
import HomePage from './components/HomePage';
import Login from './pages/Login';
import Register from './pages/Register';

function App() {
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [user, setUser] = useState(null);

  const handleRefresh = () => setRefreshTrigger(prev => prev + 1);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const isAuthenticated = !!user;

  return (
    <Router>
      {isAuthenticated && <Navbar user={user} setUser={setUser} />}

      {/* Conditionally apply layout styling */}
      <div className={isAuthenticated ?"pt-20 min-h-screen bg-gradient-to-br from-green-100 to-green-300 px-4 sm:px-6": ""}>
        <Routes>
          <Route
            path="/"
            element={
              isAuthenticated ? (
                <HomePage refreshTrigger={refreshTrigger} handleRefresh={handleRefresh} />
              ) : (
                <Navigate to="/login" />
              )
            }
          />
          <Route
            path="/dashboard"
            element={
              isAuthenticated ? (
                <div className="max-w-6xl mx-auto grid gap-6">
                  <div className="bg-white rounded-xl shadow p-6">
                    <BinDashboard refreshTrigger={refreshTrigger} />
                  </div>
                  <div className="bg-white rounded-xl shadow p-6">
                    <BinTable
                      onBinUpdated={handleRefresh}
                      refreshTrigger={refreshTrigger}
                      onDelete={handleRefresh}
                    />
                  </div>
                </div>
              ) : (
                <Navigate to="/login" />
              )
            }
          />
          <Route
            path="/map"
            element={
              isAuthenticated ? (
                <div className="max-w-6xl mx-auto bg-white rounded-xl shadow p-6">
                  <BinMap refreshTrigger={refreshTrigger} />
                </div>
              ) : (
                <Navigate to="/login" />
              )
            }
          />
          <Route
            path="/add"
            element={
              isAuthenticated ? (
                <div className="max-w-6xl mx-auto bg-white rounded-xl shadow p-6">
                  <AddBinForm onBinAdded={handleRefresh} />
                </div>
              ) : (
                <Navigate to="/login" />
              )
            }
          />
          <Route
            path="/analytics"
            element={
              isAuthenticated ? (
                <div className="max-w-6xl mx-auto bg-white rounded-xl shadow p-6">
                  <BinAnalytics refreshTrigger={refreshTrigger} />
                </div>
              ) : (
                <Navigate to="/login" />
              )
            }
          />
          <Route
            path="/fetch"
            element={
              isAuthenticated ? (
                <div className="max-w-6xl mx-auto bg-white rounded-xl shadow p-6">
                  <br />
                  <br />
                  <h1>Fetch Route page.</h1>
                </div>
              ) : (
                <Navigate to="/login" />
              )
            }
          />
          <Route
            path="/login"
            element={
              isAuthenticated ? (
                <Navigate to="/" />
              ) : (
                <Login setUser={setUser} />
              )
            }
          />
          <Route
            path="/register"
            element={
              isAuthenticated ? (
                <Navigate to="/" />
              ) : (
                <Register />
              )
            }
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
